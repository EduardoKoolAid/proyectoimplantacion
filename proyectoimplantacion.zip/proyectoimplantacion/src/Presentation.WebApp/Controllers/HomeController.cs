using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Presentation.WebApp.Models;
using Domain;
using Infrastructure;

namespace Presentation.WebApp.Controllers;


public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly AlumnosDbContext _alumnosDbContext;


    public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
    {
        _alumnosDbContext = new AlumnosDbContext(configuration.GetConnectionString("DefaultConnection"));
        _logger = logger;
    }

    public IActionResult Index()
    {
        var alumnos = _alumnosDbContext.List();
        ViewBag.Chart1Labels = alumnos
            .GroupBy(x => x.Nombre)
            .Select(x => $"'{x.Key}'")
            .ToList();

        ViewBag.Chart1Data = alumnos
            .GroupBy(x => x.Nombre)
            .Select(x => $"{x.Count()}")
            .ToList();
        ViewBag.Count = alumnos.Count;

        return View(alumnos);
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
